# visualization.py

import numpy as np
import matplotlib.pyplot as plt


def plot_signal(signal, fs, title):

    time = np.arange(len(signal)) / fs

    plt.figure(figsize=(10, 4))
    plt.plot(time, signal)

    plt.title(title)
    plt.xlabel("Tiempo [s]")
    plt.ylabel("Amplitud")

    plt.grid(True)
    plt.show()


def plot_spectrum(freqs, spectrum, title):

    magnitude = np.abs(spectrum)

    plt.figure(figsize=(10, 4))
    plt.plot(freqs, magnitude)

    plt.title(title)
    plt.xlabel("Frecuencia [Hz]")
    plt.ylabel("Magnitud")

    plt.xlim(0, 20000)

    plt.grid(True)
    plt.show()