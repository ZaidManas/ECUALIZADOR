# config.py

INPUT_FILE = "audiooriginal.wav"
OUTPUT_FILE = "audioprocesado.wav"

BASS_RANGE = (20, 250)
MID_RANGE = (250, 4000)
TREBLE_RANGE = (4000, 20000)