# spectral_processing.py

import numpy as np
from config import *


def compute_fft(signal):

    return np.fft.fft(signal)


def compute_ifft(spectrum):

    return np.real(np.fft.ifft(spectrum))


def get_frequencies(N, fs):

    return np.fft.fftfreq(N, d=1/fs)


def apply_equalizer(
    spectrum,
    freqs,
    bass_gain,
    mid_gain,
    treble_gain
):

    modified = spectrum.copy()

    bass_mask = (
        (np.abs(freqs) >= BASS_RANGE[0]) &
        (np.abs(freqs) <= BASS_RANGE[1])
    )

    mid_mask = (
        (np.abs(freqs) >= MID_RANGE[0]) &
        (np.abs(freqs) <= MID_RANGE[1])
    )

    treble_mask = (
        (np.abs(freqs) >= TREBLE_RANGE[0]) &
        (np.abs(freqs) <= TREBLE_RANGE[1])
    )

    modified[bass_mask] *= bass_gain
    modified[mid_mask] *= mid_gain
    modified[treble_mask] *= treble_gain

    return modified