# interface.py

def get_user_gains():

    print("=== CONFIGURACIÓN DEL ECUALIZADOR ===")

    bass = float(input("Ganancia bajos: "))
    mid = float(input("Ganancia medios: "))
    treble = float(input("Ganancia agudos: "))

    return bass, mid, treble