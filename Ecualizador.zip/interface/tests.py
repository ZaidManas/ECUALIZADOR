# tests/tests.py

import numpy as np
from modules.spectral_processing import (
    compute_fft,
    compute_ifft
)


def test_fft_ifft():

    signal = np.random.rand(1024)

    spectrum = compute_fft(signal)

    reconstructed = compute_ifft(spectrum)

    error = np.max(np.abs(signal - reconstructed))

    print("Error máximo:", error)


if __name__ == "__main__":
    test_fft_ifft()