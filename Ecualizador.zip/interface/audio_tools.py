# audio_tools.py

import numpy as np
import soundfile as sf
import sounddevice as sd


def load_audio(path):

    signal, fs = sf.read(path)

    if len(signal.shape) > 1:
        signal = np.mean(signal, axis=1)

    return signal, fs


def save_audio(path, signal, fs):

    sf.write(path, signal, fs)


def play_audio(signal, fs):

    sd.play(signal, fs)
    sd.wait()


def normalize_audio(signal):

    max_value = np.max(np.abs(signal))

    if max_value == 0:
        return signal

    return signal / max_value