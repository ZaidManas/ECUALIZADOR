# controller.py

from config import *
from audio_tools import (
    load_audio,
    save_audio,
    normalize_audio
)

from spectral_processing import (
    compute_fft,
    compute_ifft,
    get_frequencies,
    apply_equalizer
)

from visualization import (
    plot_signal,
    plot_spectrum
)

from interface import get_user_gains


def run():

    bass_gain, mid_gain, treble_gain = get_user_gains()

    signal, fs = load_audio(INPUT_FILE)

    spectrum = compute_fft(signal)

    freqs = get_frequencies(len(signal), fs)

    modified_spectrum = apply_equalizer(
        spectrum,
        freqs,
        bass_gain,
        mid_gain,
        treble_gain
    )

    reconstructed = compute_ifft(modified_spectrum)

    reconstructed = normalize_audio(reconstructed)

    save_audio(OUTPUT_FILE, reconstructed, fs)

    plot_signal(signal, fs, "Señal Original")
    plot_signal(reconstructed, fs, "Señal Ecualizada")

    plot_spectrum(freqs, spectrum, "Espectro Original")
    plot_spectrum(freqs, modified_spectrum, "Espectro Ecualizado")

    print("Procesamiento completado.")