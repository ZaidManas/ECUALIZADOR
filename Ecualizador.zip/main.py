#Version 3.5

import tkinter as tk
import customtkinter as ckt
from tkinter import filedialog, messagebox
import numpy as np
import sounddevice as sd
import os
import time
import sys
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.figure import Figure

# ─── TRUCO PRINCIPAL PARA CORREGIR EL ICONO EN LA BARRA DE TAREAS ───
if sys.platform.startswith("win"):
    import ctypes
    # Forzar a Windows a reconocer esto como una App única y no como un script genérico de Python
    myappid = "studioequalizer.pro.suite.v2"
    ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(myappid)

# Importaciones de tus módulos existentes
from config import INPUT_FILE, OUTPUT_FILE
from audio_tools import load_audio, save_audio, normalize_audio
from spectral_processing import compute_fft, compute_ifft, get_frequencies, apply_equalizer

# Configuración estética Premium
ckt.set_appearance_mode("Dark")       
ckt.set_default_color_theme("blue")  

class ProStudioEqualizer(ckt.CTk):
    def __init__(self):
        super().__init__()

        # Configuración de la Ventana Principal
        self.title("StudioEqualizer PRO - Premium Audio Suite")
        self.geometry("1250x800")
        self.minsize(1100, 750)
        
        # ASIGNACIÓN DEL NUEVO LOGO
        # Busca el archivo logo.ico en la misma carpeta
        self.icon_path = "logo.ico"
        if os.path.exists(self.icon_path):
            self.iconbitmap(self.icon_path)
        
        self.protocol("WM_DELETE_WINDOW", self.on_closing)

        # Variables de estado del audio
        self.file_path = INPUT_FILE
        self.signal = None
        self.fs = None
        self.duration = 0.0
        self.spectrum = None
        self.freqs = None
        self.processed_signal = None
        self.processed_spectrum = None  

        # Historial / Playlist de audios cargados
        self.playlist = []
        self.playlist_buttons = []

        # Control de reproducción y modificadores
        self.is_playing = False
        self.start_time = 0.0
        self.pause_offset = 0.0
        self.low_cut_filter_active = False  
        
        # Variable para distribuir pantallas
        self.current_layout = "dual" 

        # Construcción de la UI
        self.setup_ui()
        self.init_plot()
        
        # Cargar audio inicial si existe
        if os.path.exists(self.file_path):
            self.add_file_to_playlist(self.file_path)

    def setup_ui(self):
        # Distribución principal: Panel lateral fijo | Contenedor de trabajo expansivo
        self.grid_columnconfigure(0, weight=0, minsize=320)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        # =================================================================
        # ─── PANEL LATERAL IZQUIERDO (PLAYLIST & TRANSPORTES) ────────────
        # =================================================================
        sidebar = ckt.CTkFrame(self, corner_radius=0, fg_color="#0F0F13")
        sidebar.grid(row=0, column=0, sticky="nsew")
        
        # Branding elegante
        brand_label = ckt.CTkLabel(sidebar, text="STUDIO EQ", font=ckt.CTkFont(family="Helvetica", size=24, weight="bold"))
        brand_label.pack(pady=(30, 5))
        version_label = ckt.CTkLabel(sidebar, text="V2.8 BRANDED INTERFACE", font=ckt.CTkFont(size=10, weight="bold"), text_color="#6366F1")
        version_label.pack(pady=(0, 20))

        # Botón de carga principal
        self.btn_load = ckt.CTkButton(
            sidebar, text="+ Importar Audio .wav", 
            font=ckt.CTkFont(weight="bold"), fg_color="#4F46E5", hover_color="#4338CA",
            command=self.browse_file
        )
        self.btn_load.pack(fill="x", padx=25, pady=10)

        # Contenedor de Playlist con Scrollbar moderno
        ckt.CTkLabel(sidebar, text="LISTA DE REPRODUCCIÓN", font=ckt.CTkFont(size=11, weight="bold"), text_color="#6B7280").pack(anchor="w", padx=25, pady=(15, 5))
        
        self.playlist_frame = ckt.CTkScrollableFrame(sidebar, fg_color="#15151E", corner_radius=10, height=220)
        self.playlist_frame.pack(fill="x", padx=25, pady=5)
        
        # Controles de reproducción globales (Transportes)
        transport_box = ckt.CTkFrame(sidebar, fg_color="#15151E", corner_radius=12)
        transport_box.pack(fill="x", padx=25, pady=20)

        # Fila de Botones multimedia
        btn_row = ckt.CTkFrame(transport_box, fg_color="transparent")
        btn_row.pack(fill="x", padx=15, pady=(15, 8))
        
        self.btn_play = ckt.CTkButton(btn_row, text="▶", width=55, fg_color="#10B981", hover_color="#059669", font=ckt.CTkFont(size=16), command=self.play_audio)
        self.btn_play.pack(side="left", expand=True, padx=3)

        self.btn_pause = ckt.CTkButton(btn_row, text="⏸", width=55, font=ckt.CTkFont(size=16), command=self.pause_audio)
        self.btn_pause.pack(side="left", expand=True, padx=3)

        self.btn_stop = ckt.CTkButton(btn_row, text="⏹", width=55, fg_color="#EF4444", hover_color="#DC2626", font=ckt.CTkFont(size=16), command=self.stop_audio)
        self.btn_stop.pack(side="left", expand=True, padx=3)

        # Slider de posición de reproducción
        self.pos_slider = ckt.CTkSlider(transport_box, from_=0, to=100, number_of_steps=1000, progress_color="#6366F1")
        self.pos_slider.pack(fill="x", padx=15, pady=5)
        self.pos_slider.set(0)
        self.pos_slider.bind("<ButtonRelease-1>", lambda e: self.safe_update(self.on_pos_slider_move))

        self.time_label = ckt.CTkLabel(transport_box, text="0.0s / 0.0s", font=ckt.CTkFont(family="Courier", size=11, weight="bold"), text_color="#9CA3AF")
        self.time_label.pack(anchor="e", padx=15, pady=(0, 15))

        # =================================================================
        # ─── PANEL CENTRAL DERECHO (ESTACIÓN DE TRABAJO GRÁFICA) ─────────
        # =================================================================
        workspace = ckt.CTkFrame(self, corner_radius=0, fg_color="#12121A")
        workspace.grid(row=0, column=1, sticky="nsew", padx=0, pady=0)
        workspace.grid_rowconfigure(0, weight=5) 
        workspace.grid_rowconfigure(1, weight=2) 
        workspace.grid_columnconfigure(0, weight=1)

        # Contenedor superior para la pantalla de Matplotlib
        graph_card = ckt.CTkFrame(workspace, fg_color="#1A1A24", corner_radius=12)
        graph_card.grid(row=0, column=0, padx=25, pady=(25, 12), sticky="nsew")
        
        self.plot_container = tk.Frame(graph_card, bg='#1A1A24')
        self.plot_container.pack(fill="both", expand=True, padx=15, pady=(15, 5))

        # Contenedor inferior unificado para Controles de Distribución y Herramientas Matplotlib
        self.toolbar_container = tk.Frame(graph_card, bg='#1A1A24')
        self.toolbar_container.pack(fill="x", padx=15, pady=(0, 10))

        # Subcontenedor izquierdo para botones de distribución de pantalla (Layout)
        layout_bar = tk.Frame(self.toolbar_container, bg='#1A1A24')
        layout_bar.pack(side="left", fill="y", padx=(0, 20))
        
        tk.Label(layout_bar, text="Distribución:", bg='#1A1A24', fg='#6B7280', font=("Helvetica", 9, "bold")).pack(side="left", padx=(0, 5))
        
        self.btn_layout_dual = tk.Button(layout_bar, text="Vista Dual", bg='#4F46E5', fg='white', font=("Helvetica", 9), relief="flat", command=lambda: self.change_layout("dual"))
        self.btn_layout_dual.pack(side="left", padx=2)
        
        self.btn_layout_time = tk.Button(layout_bar, text="Solo Tiempo", bg='#222230', fg='white', font=("Helvetica", 9), relief="flat", command=lambda: self.change_layout("time_only"))
        self.btn_layout_time.pack(side="left", padx=2)
        
        self.btn_layout_freq = tk.Button(layout_bar, text="Solo Frecuencia (FFT)", bg='#222230', fg='white', font=("Helvetica", 9), relief="flat", command=lambda: self.change_layout("freq_only"))
        self.btn_layout_freq.pack(side="left", padx=2)

        # Contenedor inferior: Consola Modular por Pestañas (Tabs)
        console_card = ckt.CTkFrame(workspace, fg_color="#1A1A24", corner_radius=12)
        console_card.grid(row=1, column=0, padx=25, pady=(12, 25), sticky="nsew")
        
        self.tabs = ckt.CTkTabview(console_card, fg_color="#1A1A24", segmented_button_selected_color="#4F46E5", segmented_button_unselected_hover_color="#312E81")
        self.tabs.pack(fill="both", expand=True, padx=10, pady=5)
        
        tab_eq = self.tabs.add("🎛️ Ecualizador de Bandas")
        tab_presets = self.tabs.add("✨ Presets & Estilos")
        tab_effects = self.tabs.add("🚀 Filtros Avanzados")

        # ─── CONTENIDO TAB 1: ECUALIZADOR MANUAL ───
        tab_eq.grid_columnconfigure((0, 1, 2, 3), weight=1)
        
        # Master Volumen
        v_box = ckt.CTkFrame(tab_eq, fg_color="#222230", corner_radius=8)
        v_box.grid(row=0, column=0, padx=10, pady=15, sticky="nsew")
        ckt.CTkLabel(v_box, text="Master Vol", font=ckt.CTkFont(size=11, weight="bold"), text_color="#A7F3D0").pack(pady=5)
        self.vol_slider = ckt.CTkSlider(v_box, from_=0.0, to=2.0, progress_color="#10B981")
        self.vol_slider.pack(fill="x", padx=15, pady=10)
        self.vol_slider.set(1.0)
        self.vol_slider.bind("<ButtonRelease-1>", lambda e: self.safe_update(self.apply_volume_changes))

        # Slider de Graves
        b_box = ckt.CTkFrame(tab_eq, fg_color="#222230", corner_radius=8)
        b_box.grid(row=0, column=1, padx=10, pady=15, sticky="nsew")
        ckt.CTkLabel(b_box, text="Bass (Graves)", font=ckt.CTkFont(size=11, weight="bold")).pack(pady=5)
        self.bass_slider = ckt.CTkSlider(b_box, from_=0.0, to=3.0, progress_color="#6366F1")
        self.bass_slider.pack(fill="x", padx=15, pady=10)
        self.bass_slider.set(1.0)
        self.bass_slider.bind("<ButtonRelease-1>", lambda e: self.safe_update(self.apply_spectral_changes))

        # Slider de Medios
        m_box = ckt.CTkFrame(tab_eq, fg_color="#222230", corner_radius=8)
        m_box.grid(row=0, column=2, padx=10, pady=15, sticky="nsew")
        ckt.CTkLabel(m_box, text="Mid (Medios)", font=ckt.CTkFont(size=11, weight="bold")).pack(pady=5)
        self.mid_slider = ckt.CTkSlider(m_box, from_=0.0, to=3.0, progress_color="#6366F1")
        self.mid_slider.pack(fill="x", padx=15, pady=10)
        self.mid_slider.set(1.0)
        self.mid_slider.bind("<ButtonRelease-1>", lambda e: self.safe_update(self.apply_spectral_changes))

        # Slider de Agudos
        t_box = ckt.CTkFrame(tab_eq, fg_color="#222230", corner_radius=8)
        t_box.grid(row=0, column=3, padx=10, pady=15, sticky="nsew")
        ckt.CTkLabel(t_box, text="Treble (Agudos)", font=ckt.CTkFont(size=11, weight="bold")).pack(pady=5)
        self.treble_slider = ckt.CTkSlider(t_box, from_=0.0, to=3.0, progress_color="#6366F1")
        self.treble_slider.pack(fill="x", padx=15, pady=10)
        self.treble_slider.set(1.0)
        self.treble_slider.bind("<ButtonRelease-1>", lambda e: self.safe_update(self.apply_spectral_changes))

        # Botones de utilidad
        eq_actions = ckt.CTkFrame(tab_eq, fg_color="transparent")
        eq_actions.grid(row=1, column=0, columnspan=4, sticky="ew", pady=(5, 0))
        ckt.CTkButton(eq_actions, text="🔄 Reset Mezcladora", fg_color="#374151", hover_color="#4B5563", width=160, command=self.reset_amplifiers).pack(side="left", padx=10)
        ckt.CTkButton(eq_actions, text="💾 Renderizar & Exportar", fg_color="#10B981", hover_color="#059669", width=180, command=self.save_audio_file).pack(side="right", padx=10)

        # ─── CONTENIDO TAB 2: PRESETS ───
        tab_presets.grid_columnconfigure(0, weight=1)
        preset_box = ckt.CTkFrame(tab_presets, fg_color="#222230", corner_radius=10)
        preset_box.pack(fill="both", expand=True, padx=20, pady=15)
        ckt.CTkLabel(preset_box, text="Selecciona un perfil acústico preconfigurado:", font=ckt.CTkFont(size=13, weight="bold")).pack(pady=(15, 10))
        self.preset_menu = ckt.CTkOptionMenu(
            preset_box, 
            values=["Manual (Personalizado)", "Bass Boost (Super Graves)", "Pop Vocal (Foco Voces)", "Metal / Rock (Agresivo)", "Flat (Plano/Original)"],
            width=260, fg_color="#4F46E5", button_color="#4338CA",
            command=self.on_preset_selected
        )
        self.preset_menu.pack(pady=10)
        self.preset_menu.set("Manual (Personalizado)")

        # ─── CONTENIDO TAB 3: FILTROS AVANZADOS ───
        tab_effects.grid_columnconfigure(0, weight=1)
        fx_box = ckt.CTkFrame(tab_effects, fg_color="#222230", corner_radius=10)
        fx_box.pack(fill="both", expand=True, padx=20, pady=15)
        ckt.CTkLabel(fx_box, text="Filtro de Limpieza de Frecuencias Especial", font=ckt.CTkFont(size=13, weight="bold")).pack(pady=(15, 5))
        self.switch_lowcut = ckt.CTkSwitch(
            fx_box, text="Activar Filtro Low-Cut (Corte de sub-graves < 80Hz)", 
            font=ckt.CTkFont(size=12), progress_color="#6366F1",
            command=self.toggle_low_cut_filter
        )
        self.switch_lowcut.pack(pady=15)

    def init_plot(self):
        self.fig = Figure(figsize=(6, 4.5), dpi=100, facecolor='#1A1A24')
        self.canvas = FigureCanvasTkAgg(self.fig, master=self.plot_container)
        self.canvas.get_tk_widget().pack(fill="both", expand=True)

        self.build_subplots()

        # Barra de herramientas nativa Matplotlib (derecha)
        self.toolbar = NavigationToolbar2Tk(self.canvas, self.toolbar_container, pack_toolbar=False)
        self.toolbar.pack(side="right", fill="x")
        self.toolbar.configure(bg='#1A1A24')
        self.toolbar._message_label.config(bg='#1A1A24', fg='#6B7280') 
        
        for button in self.toolbar.winfo_children():
            if isinstance(button, (tk.Button, tk.Checkbutton)):
                button.config(bg='#222230', fg='white', activebackground='#4F46E5')
                
        self.toolbar.update()

    def build_subplots(self):
        self.fig.clear()
        
        if self.current_layout == "dual":
            self.ax_time = self.fig.add_subplot(211)
            self.ax_freq = self.fig.add_subplot(212)
        elif self.current_layout == "time_only":
            self.ax_time = self.fig.add_subplot(111)
            self.ax_freq = None
        elif self.current_layout == "freq_only":
            self.ax_time = None
            self.ax_freq = self.fig.add_subplot(111)

        for ax in [self.ax_time, self.ax_freq]:
            if ax is not None:
                ax.set_facecolor('#0F0F14')
                ax.tick_params(colors='#6B7280', labelsize=8)
                ax.xaxis.label.set_color('#6B7280')
                ax.yaxis.label.set_color('#6B7280')

        self.fig.tight_layout()

    def change_layout(self, layout_mode):
        self.current_layout = layout_mode
        
        self.btn_layout_dual.config(bg='#4F46E5' if layout_mode == "dual" else '#222230')
        self.btn_layout_time.config(bg='#4F46E5' if layout_mode == "time_only" else '#222230')
        self.btn_layout_freq.config(bg='#4F46E5' if layout_mode == "freq_only" else '#222230')
        
        self.build_subplots()
        self.plot_audio_graphs()
        self.toolbar.update()

    def safe_update(self, callback_func):
        self.after_idle(callback_func)

    # =================================================================
    # ─── LÓGICA DE GESTIÓN DE PLAYLIST (MÚLTIPLES AUDIOS) ────────────
    # =================================================================
    def browse_file(self):
        path = filedialog.askopenfilename(filetypes=[("WAV Audio", "*.wav")])
        if path:
            self.add_file_to_playlist(path)

    def add_file_to_playlist(self, path):
        if path not in self.playlist:
            self.playlist.append(path)
            filename = os.path.basename(path)
            
            btn = ckt.CTkButton(
                self.playlist_frame, text=f"🎵 {filename}", 
                anchor="w", fg_color="#1E1E2E", hover_color="#2D2D44",
                command=lambda p=path: self.select_track_from_playlist(p)
            )
            btn.pack(fill="x", padx=5, pady=4)
            self.playlist_buttons.append((path, btn))
        
        self.select_track_from_playlist(path)

    def select_track_from_playlist(self, path):
        self.stop_audio()
        self.file_path = path
        
        for p, btn in self.playlist_buttons:
            if p == path:
                btn.configure(fg_color="#312E81", text_color="#F3F4F6")
            else:
                btn.configure(fg_color="#1E1E2E", text_color="#9CA3AF")
                
        self.load_audio_file(path)

    def load_audio_file(self, path):
        try:
            self.signal, self.fs = load_audio(path)
            self.duration = len(self.signal) / self.fs
            
            self.spectrum = compute_fft(self.signal)
            self.freqs = get_frequencies(len(self.signal), self.fs)
            
            self.processed_signal = self.signal.copy()
            self.processed_spectrum = self.spectrum.copy()

            self.pos_slider.configure(to=self.duration)
            self.pos_slider.set(0)
            self.time_label.configure(text=f"0.0s / {self.duration:.1f}s")

            self.apply_spectral_changes()
        except Exception as e:
            messagebox.showerror("Error de Carga", f"No se pudo procesar el archivo:\n{str(e)}")

    def reset_ui_sliders(self):
        self.bass_slider.set(1.0)
        self.mid_slider.set(1.0)
        self.treble_slider.set(1.0)
        self.preset_menu.set("Manual (Personalizado)")

    def reset_amplifiers(self):
        if self.signal is None:
            return
        self.reset_ui_sliders()
        self.safe_update(self.apply_spectral_changes)

    # =================================================================
    # ─── RENDERIZADO GRÁFICO SELECCIONABLE ───────────────────────────
    # =================================================================
    def plot_audio_graphs(self):
        if self.processed_signal is None or self.processed_spectrum is None:
            return

        if self.ax_time is not None:
            xlim_time = self.ax_time.get_xlim() if self.ax_time.has_data() else None
            ylim_time = self.ax_time.get_ylim() if self.ax_time.has_data() else (-1.1, 1.1)
            self.ax_time.clear()
            
            time_axis = np.arange(len(self.processed_signal)) / self.fs
            if len(time_axis) > 12000:
                step = len(time_axis) // 12000
                self.ax_time.plot(time_axis[::step], self.processed_signal[::step], color='#6366F1', alpha=0.9, linewidth=1)
            else:
                self.ax_time.plot(time_axis, self.processed_signal, color='#6366F1', alpha=0.9, linewidth=1)
                
            self.ax_time.set_title("Forma de Onda Temporal (Dominio del Tiempo)", fontsize=10, fontweight="bold", pad=4, color="white")
            self.ax_time.set_ylabel("Amplitud", fontsize=8)
            self.ax_time.grid(True, linestyle=":", color="#2A2A35", alpha=0.4)
            
            if xlim_time and xlim_time != (0.0, 1.0):
                self.ax_time.set_xlim(xlim_time)
                self.ax_time.set_ylim(ylim_time)
            else:
                self.ax_time.set_ylim(-1.1, 1.1)

        if self.ax_freq is not None:
            xlim_freq = self.ax_freq.get_xlim() if self.ax_freq.has_data() else (0, 20000)
            ylim_freq = self.ax_freq.get_ylim() if self.ax_freq.has_data() else None
            self.ax_freq.clear()
            
            magnitude = np.abs(self.processed_spectrum)
            if len(self.freqs) > 12000:
                step_f = len(self.freqs) // 12000
                self.ax_freq.plot(self.freqs[::step_f], magnitude[::step_f], color='#10B981', alpha=0.9, linewidth=1)
            else:
                self.ax_freq.plot(self.freqs, magnitude, color='#10B981', alpha=0.9, linewidth=1)
                
            self.ax_freq.set_title("Espectro de Frecuencias (Transformada de Fourier - FFT)", fontsize=10, fontweight="bold", pad=4, color="white")
            self.ax_freq.set_xlabel("Frecuencia [Hz]", fontsize=8)
            self.ax_freq.set_ylabel("Magnitud", fontsize=8)
            self.ax_freq.grid(True, linestyle=":", color="#2A2A35", alpha=0.4)

            if xlim_freq and xlim_freq != (0.0, 1.0):
                self.ax_freq.set_xlim(xlim_freq)
                if ylim_freq: self.ax_freq.set_ylim(ylim_freq)
            else:
                self.ax_freq.set_xlim(0, 20000)

        self.fig.tight_layout()
        self.canvas.draw()

    # =================================================================
    # ─── CONTROLES DE REPRODUCCIÓN ───────────────────────────────────
    # =================================================================
    def play_audio(self):
        if self.processed_signal is None:
            return

        if not self.is_playing:
            start_sample = int(self.pause_offset * self.fs)
            if start_sample >= len(self.processed_signal):
                start_sample = 0
                self.pause_offset = 0.0

            vol = self.vol_slider.get()
            audio_chunk = self.processed_signal[start_sample:] * vol

            sd.play(audio_chunk, self.fs)
            self.start_time = time.time() - self.pause_offset
            self.is_playing = True
            self.update_playback_timer()

    def pause_audio(self):
        if self.is_playing:
            sd.stop()
            self.is_playing = False
            self.pause_offset = time.time() - self.start_time

    def stop_audio(self):
        sd.stop()
        self.is_playing = False
        self.pause_offset = 0.0
        self.pos_slider.set(0)
        if self.duration > 0:
            self.time_label.configure(text=f"0.0s / {self.duration:.1f}s")

    def update_playback_timer(self):
        if self.is_playing:
            elapsed = time.time() - self.start_time
            if elapsed >= self.duration:
                self.stop_audio()
            else:
                self.pos_slider.set(elapsed)
                self.time_label.configure(text=f"{elapsed:.1f}s / {self.duration:.1f}s")
                self.after(100, self.update_playback_timer)

    def on_pos_slider_move(self):
        if self.signal is not None:
            self.pause_offset = self.pos_slider.get()
            if self.is_playing:
                sd.stop()
                self.is_playing = False
                self.play_audio()
            else:
                self.time_label.configure(text=f"{self.pause_offset:.1f}s / {self.duration:.1f}s")

    def apply_volume_changes(self):
        if self.is_playing:
            self.pause_offset = time.time() - self.start_time
            sd.stop()
            self.is_playing = False
            self.play_audio()

    # =================================================================
    # ─── PROCESAMIENTO AVANZADO Y PRESETS ────────────────────────────
    # =================================================================
    def on_preset_selected(self, preset_name):
        if self.signal is None:
            return
            
        if preset_name == "Bass Boost (Super Graves)":
            self.bass_slider.set(2.4)
            self.mid_slider.set(1.0)
            self.treble_slider.set(0.8)
        elif preset_name == "Pop Vocal (Foco Voces)":
            self.bass_slider.set(0.7)
            self.mid_slider.set(2.2)
            self.treble_slider.set(1.3)
        elif preset_name == "Metal / Rock (Agresivo)":
            self.bass_slider.set(1.8)
            self.mid_slider.set(0.6)
            self.treble_slider.set(2.0)
        elif preset_name == "Flat (Plano/Original)":
            self.bass_slider.set(1.0)
            self.mid_slider.set(1.0)
            self.treble_slider.set(1.0)

        self.apply_spectral_changes()

    def toggle_low_cut_filter(self):
        self.low_cut_filter_active = self.switch_lowcut.get()
        self.apply_spectral_changes()

    def apply_spectral_changes(self):
        if self.signal is None:
            return

        b_gain = self.bass_slider.get()
        m_gain = self.mid_slider.get()
        t_gain = self.treble_slider.get()

        modified_spectrum = apply_equalizer(self.spectrum, self.freqs, b_gain, m_gain, t_gain)
        
        if self.low_cut_filter_active:
            low_cut_mask = np.abs(self.freqs) < 80
            modified_spectrum[low_cut_mask] *= 0.05  

        self.processed_spectrum = modified_spectrum
        
        reconstructed = compute_ifft(modified_spectrum)
        self.processed_signal = normalize_audio(reconstructed)

        self.plot_audio_graphs()

        if self.is_playing:
            self.pause_offset = time.time() - self.start_time
            sd.stop()
            self.is_playing = False
            self.play_audio()

    def save_audio_file(self):
        if self.processed_signal is None:
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".wav",
            filetypes=[("WAV Audio", "*.wav")],
            initialfile=OUTPUT_FILE
        )
        if path:
            save_audio(path, self.processed_signal, self.fs)
            messagebox.showinfo("Suite Pro", f"Audio procesado exportado con éxito en:\n{path}")

    def on_closing(self):
        sd.stop()
        self.destroy()

if __name__ == "__main__":
    app = ProStudioEqualizer()
    app.mainloop()